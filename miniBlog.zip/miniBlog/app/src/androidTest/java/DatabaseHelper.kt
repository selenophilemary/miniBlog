import Article.Article
import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class DatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "blog.db"
        private const val DATABASE_VERSION = 1

        // Noms des tables et des colonnes
        private const val TABLE_ARTICLES = "articles"
        private const val COLUMN_ID = "id"
        private const val COLUMN_TITLE = "title"
        private const val COLUMN_CONTENT = "content"
        private const val COLUMN_DATE = "date"
    }

    override fun onCreate(db: SQLiteDatabase) {
        // Création de la table des articles
        val createTableQuery = "CREATE TABLE $TABLE_ARTICLES (" +
                "$COLUMN_ID INTEGER PRIMARY KEY AUTOINCREMENT," +
                "$COLUMN_TITLE TEXT," +
                "$COLUMN_CONTENT TEXT," +
                "$COLUMN_DATE TEXT" +
                ")"
        db.execSQL(createTableQuery)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Méthode appelée lors de la mise à jour de la base de données
        // Vous pouvez implémenter ici les modifications nécessaires
    }

    // Méthode pour ajouter un nouvel article
    fun addArticle(title: String, content: String, date: String): Long {
        val values = ContentValues()
        values.put(COLUMN_TITLE, title)
        values.put(COLUMN_CONTENT, content)
        values.put(COLUMN_DATE, date)

        val db = writableDatabase
        return db.insert(TABLE_ARTICLES, null, values)
    }

    // Méthode pour récupérer tous les articles
    fun getAllArticles(): ArrayList<Article> {
        val articlesList = ArrayList<Article>()
        val selectQuery = "SELECT * FROM $TABLE_ARTICLES"

        val db = readableDatabase
        val cursor: Cursor? = db.rawQuery(selectQuery, null)

        cursor?.let {
            if (it.moveToFirst()) {
                do {
                    val id = cursor.getInt(cursor.getColumnIndex(COLUMN_ID))
                    val title = cursor.getString(cursor.getColumnIndex(COLUMN_TITLE))
                    val content = cursor.getString(cursor.getColumnIndex(COLUMN_CONTENT))
                    val date = cursor.getString(cursor.getColumnIndex(COLUMN_DATE))

                    val article = Article(id, title, content, date)
                    articlesList.add(article)
                } while (it.moveToNext())
            }
        }
        cursor?.close()

        return articlesList
    }

    // Méthode pour mettre à jour un article existant
    fun updateArticle(id: Int, title: String, content: String, date: String): Int {
        val values = ContentValues()
        values.put(COLUMN_TITLE, title)
        values.put(COLUMN_CONTENT, content)
        values.put(COLUMN_DATE, date)

        val db = writableDatabase
        val whereClause = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(id.toString())
        return db.update(TABLE_ARTICLES, values, whereClause, whereArgs)
    }

    // Méthode pour supprimer un article
    fun deleteArticle(id: Int): Int {
        val db = writableDatabase
        val whereClause = "$COLUMN_ID = ?"
        val whereArgs = arrayOf(id.toString())
        return db.delete(TABLE_ARTICLES, whereClause, whereArgs)
    }
}


