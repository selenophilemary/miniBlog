package Article

class Article(id: Int, title: String, content: String, date: String) {

}
