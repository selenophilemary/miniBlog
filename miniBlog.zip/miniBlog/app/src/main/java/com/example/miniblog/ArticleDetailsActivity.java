package com.example.miniblog;

import android.app.Activity;

public class ArticleDetailsActivity extends Activity {
}

